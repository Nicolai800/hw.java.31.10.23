public class Main {
    public static void main(String[] args) {
        String userStr = new String("AAAABBBCCCDDEG");
        System.out.println(getChanged(userStr));

    }

    private static StringBuilder getChanged(String str) {
        StringBuilder changed = new StringBuilder();
        int counter = 0;
        char a = str.charAt(0);
        for (int i = 0; i < str.length(); i++) {
            char b = str.charAt(i);
            if (a == b) {
                counter++;
            } else {
                changed.append(a);
                changed.append(counter == 1 ? "" : counter);
                counter = 1;
                a = b;
            }
        }
        changed.append(a);
        changed.append(counter == 1 ? " " : counter);
        return changed;
    }
}


/*Дана строка вида AAAABBBCCCDDEG…, состоящая только из заглавных символов латинского алфавита.
Напишите метод, который «свернёт» строку к виду A4B3C3D2EG, т.е. количество букв записывается цифрой.
Если буква одна, то цифра не ставится.*/
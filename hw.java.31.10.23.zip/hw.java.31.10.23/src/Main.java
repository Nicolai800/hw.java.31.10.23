import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println("Введите первое слово состоящие из четного количества букв");
        String firstWord = scr.nextLine();
        System.out.println("Введите первое слово состоящие из четного количества букв");
        String secondWord = scr.nextLine();
        int fLetterCount = firstWord.length();
        System.out.println("Количество букв в первом слове: " + fLetterCount);
        int sLetterCount = secondWord.length();
        System.out.println("Количество букв во втором слове: " + sLetterCount);
        for (int i = 0; i < fLetterCount / 2; i++) {
            System.out.print(firstWord.charAt(i));
        }
        for (int i = sLetterCount/2; i < secondWord.length(); i++) {
            System.out.print(secondWord.charAt(i));
        }
    }
}


/*Введите 2 слова, воспользуйтесь сканером, состоящие из четного количества букв (проверьте количество букв в слове).
Нужно получить слово, состоящее из первой половины первого слова и второй половины второго слова. распечатать на консоль.
Например: ввод - mama, papa. Вывод – mapa*/